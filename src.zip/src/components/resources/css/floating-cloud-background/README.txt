A Pen created at CodePen.io. You can find this one at https://codepen.io/shshaw/pen/DxJka.

 A floating cloud background using CSS Transforms, negative animation delays, and a LESS loop for nth-child staggering.