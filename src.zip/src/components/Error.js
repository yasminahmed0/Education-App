import React from 'react';

const Error =() => {
    return (
        <div>
            <ul>
                <p> Page not Found </p>
        </ul>
        </div>        
    );


};
export default Error;